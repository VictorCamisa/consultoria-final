# LAYOUT RULES — GRID, ESPAÇAMENTO, HIERARQUIA

**VS Soluções · Versão 2026.1**

---

## 1. PRINCÍPIOS

1. **Background sempre escuro.** Toda interface VS nasce em Deep Space Blue. Modo claro só em e-mails transacionais.
2. **CTA único por viewport.** Apenas uma ação primária em Cyber Orange visível ao mesmo tempo. Múltiplos botões laranja diluem a hierarquia.
3. **Espaçamento generoso.** Densidade baixa. Tipografia respira. UI apertada quebra o princípio.
4. **Restrição como força.** Em caso de dúvida, remover.

---

## 2. GRID & CONTAINERS

### Container máximo
- **Padrão**: `max-width: 1440px` (`--vs-container-2xl`)
- **Centralizado**: `margin: 0 auto`
- **Padding lateral responsivo**:
  - Mobile (`< 768px`): 16px
  - Tablet (`≥ 768px`): 32px
  - Desktop (`≥ 1280px`): 48px

### Grid interno
- **12 colunas** em desktop (`≥ 1024px`)
- **6 colunas** em tablet (`768px – 1023px`)
- **4 colunas** em mobile (`< 768px`)
- **Gap padrão**: 24px (`--vs-space-6`)

### Largura de leitura
- Texto corrido: `max-width: 65ch` (`--vs-content-narrow`)
- Cards de conteúdo: `max-width: 80ch` (`--vs-content-medium`)
- Dashboards: `100%` (`--vs-content-wide`)

---

## 3. BREAKPOINTS

Mobile-first. Use `min-width`.

| Token | Valor | Dispositivo |
|-------|-------|-------------|
| `sm` | `640px` | Mobile landscape |
| `md` | `768px` | Tablet portrait |
| `lg` | `1024px` | Tablet landscape / desktop pequeno |
| `xl` | `1280px` | Desktop padrão |
| `2xl` | `1536px` | Desktop grande |

```css
/* Padrão de uso */
@media (min-width: 768px) { /* tablet+ */ }
@media (min-width: 1024px) { /* desktop+ */ }
```

---

## 4. ESPAÇAMENTO (escala 4px)

| Token | px | Uso típico |
|-------|----|-----------:|
| `--vs-space-1` | 4px | Gaps internos de ícones |
| `--vs-space-2` | 8px | Espaçamento entre elementos próximos |
| `--vs-space-3` | 12px | Padding interno de inputs/badges |
| `--vs-space-4` | 16px | **Padding padrão de componentes** |
| `--vs-space-6` | 24px | **Gap padrão entre cards / grid** |
| `--vs-space-8` | 32px | Margem entre seções pequenas |
| `--vs-space-12` | 48px | Margem entre seções médias |
| `--vs-space-16` | 64px | **Margem padrão entre seções de página** |
| `--vs-space-24` | 96px | Margem entre seções hero |
| `--vs-space-32` | 128px | Margem hero / fim de seção principal |

### Regra de ouro
- Use sempre tokens. **Nunca** valores arbitrários (`padding: 17px`).
- Espaçamento vertical entre seções: mínimo `--vs-space-16` (64px) em desktop, `--vs-space-12` (48px) em mobile.

---

## 5. HIERARQUIA VISUAL

### Pirâmide de atenção (do topo para baixo)
1. **CTA primário** — Cyber Orange. **Único por viewport.**
2. **Headline** — Poppins Black Italic, maior tamanho da tela.
3. **Métricas/números-chave** — pode ser Cyber Orange se for um único destaque.
4. **Subheadline / parágrafo de apoio** — branco, Montserrat regular.
5. **Texto secundário** — `--vs-text-secondary` (cinza azulado).
6. **Metadados / labels** — `--vs-text-tertiary`, em mono ou caixa alta com tracking amplo.

### Regra dos 10%
Em qualquer viewport, no máximo **10% da área visível** deve estar em Cyber Orange. Mais que isso, perde força.

---

## 6. PROPORÇÃO 70/20/10

Toda peça VS deve respeitar visualmente:

- **70%** Deep Space Blue (`#050814`) — backgrounds, superfícies
- **20%** Branco (`#FFFFFF`) — texto, ícones funcionais, monograma V
- **10%** Cyber Orange (`#FF5300`) — CTAs, destaques, monograma S

Para validar, faça squint test: feche os olhos parcialmente. A tela deve aparecer dominantemente escura, com manchas brancas de texto e pontos laranja de destaque.

---

## 7. ELEVAÇÃO (camadas de superfície)

VS usa apenas **3 níveis de elevação**:

| Nível | Background | Uso |
|-------|------------|-----|
| **Base** | `--vs-deep-space` | Página, fundo geral |
| **Surface** | `--vs-surface` | Cards padrão, painéis laterais |
| **Surface 2** | `--vs-surface-2` | Modais, dropdowns, popovers |
| **Surface 3** | `--vs-surface-3` | Hover state em cards |

Mais que isso é excesso. **Não criar níveis 4+.**

### Sombras
Sombras VS são sutis e neutras. Nunca dramáticas, nunca coloridas (exceto glow do CTA em foco).

```css
/* Card padrão */
box-shadow: var(--vs-shadow-md);

/* Modal */
box-shadow: var(--vs-shadow-xl);

/* CTA em foco */
box-shadow: var(--vs-shadow-cyber);
```

---

## 8. BORDER RADIUS

| Token | px | Aplicação |
|-------|----|-----------|
| `--vs-radius-sm` | 4px | Inputs, badges pequenas, code blocks |
| `--vs-radius-md` | 8px | Botões, badges, alerts |
| `--vs-radius-lg` | 12px | **Cards padrão** |
| `--vs-radius-xl` | 16px | Cards grandes, modais |
| `--vs-radius-2xl` | 24px | Containers hero |
| `--vs-radius-full` | 9999px | Pílulas (apenas badges/avatars) |

**Regra**: nunca arredondar botões em pílula completa, exceto badges e avatars. Botões VS têm cantos firmes (8px).

---

## 9. PADRÕES DE LAYOUT POR APLICAÇÃO

### 9.1 Landing page

```
┌──────────────────────────────────────────┐
│ [Header: logo + nav + CTA secundário]    │  64px altura
├──────────────────────────────────────────┤
│                                          │
│ HERO                                     │  min-height: 80vh
│   Headline (3 tempos)                    │
│   Subheadline                            │
│   [CTA primário Cyber Orange]            │
│   [CTA secundário texto]                 │
│                                          │
├──────────────────────────────────────────┤
│ SEÇÃO PROVA SOCIAL — 3 métricas          │  padding: 96px 0
├──────────────────────────────────────────┤
│ SEÇÃO COMO FUNCIONA — 3-4 passos         │  padding: 96px 0
├──────────────────────────────────────────┤
│ SEÇÃO CASES — 2-3 cases                  │  padding: 96px 0
├──────────────────────────────────────────┤
│ SEÇÃO QUEM É A VS — 1 parágrafo curto    │  padding: 96px 0
├──────────────────────────────────────────┤
│ SEÇÃO CTA FINAL                          │  padding: 96px 0
├──────────────────────────────────────────┤
│ [Footer: logo + links + info]            │  padding: 64px 0
└──────────────────────────────────────────┘
```

### 9.2 Dashboard

```
┌──────────────────────────────────────────┐
│ [Sidebar fixa 240px] [Conteúdo]          │
│ - Logo VS                                │
│ - Nav vertical                           │
│ - User no rodapé                         │
│                                          │
│              [Header 64px: título + CTA] │
│              ┌──────────────────────────┐│
│              │ Cards de métrica (grid)  ││
│              │ KPI · KPI · KPI · KPI    ││
│              └──────────────────────────┘│
│              ┌──────────────────────────┐│
│              │ Charts / Tabela principal││
│              └──────────────────────────┘│
└──────────────────────────────────────────┘
```

### 9.3 E-mail transacional (modo claro)

- Largura fixa 600px, centralizado.
- Background `#FFFFFF`.
- Header com logo VS variação **light**.
- Botões CTA continuam em Cyber Orange (a única cor de marca que atravessa light/dark).
- Texto em Deep Space Blue `#050814`.

---

## 10. CHECKLIST DE LAYOUT

- [ ] Container máximo 1440px, centralizado, com padding responsivo?
- [ ] Espaçamento entre seções ≥ 64px (desktop)?
- [ ] Apenas UM CTA primário visível por viewport?
- [ ] Squint test mostra ~70% escuro / ~20% branco / ~10% laranja?
- [ ] Hierarquia tipográfica clara (headline > subheadline > corpo > meta)?
- [ ] No máximo 3 níveis de elevação?
- [ ] Border-radius respeita os tokens (sem valores arbitrários)?
- [ ] Layout funciona em 375px (mobile mínimo)?
