import React from 'react';
import './Table.css';

/**
 * VS Table — implementação de referência
 *
 * columns: [{ key, label, align, render?, sortable? }]
 * data: array de linhas
 * onSort: (key) => void
 * sortBy: { key, direction }
 */
export function Table({
  columns,
  data,
  emptyState,
  onRowClick,
  selectedRowKey,
  rowKey = 'id',
  sortBy,
  onSort,
  loading = false,
  ...rest
}) {
  const isEmpty = !loading && (!data || data.length === 0);

  return (
    <div className="vs-table-wrapper" {...rest}>
      <table className="vs-table">
        <thead>
          <tr>
            {columns.map((col) => {
              const sortable = col.sortable && onSort;
              const isSorted = sortBy?.key === col.key;
              return (
                <th
                  key={col.key}
                  className={`vs-table__th vs-table__th--${col.align || 'left'} ${
                    sortable ? 'vs-table__th--sortable' : ''
                  }`}
                  onClick={sortable ? () => onSort(col.key) : undefined}
                  scope="col"
                >
                  <span className="vs-table__th-label">
                    {col.label}
                    {sortable && (
                      <span
                        className={`vs-table__sort ${isSorted ? 'vs-table__sort--active' : ''}`}
                        aria-hidden="true"
                      >
                        {isSorted && sortBy.direction === 'desc' ? '↓' : '↑'}
                      </span>
                    )}
                  </span>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {loading &&
            Array.from({ length: 5 }).map((_, i) => (
              <tr key={`sk-${i}`} className="vs-table__row">
                {columns.map((col) => (
                  <td key={col.key} className="vs-table__td">
                    <div className="vs-skeleton vs-skeleton--row" />
                  </td>
                ))}
              </tr>
            ))}
          {!loading &&
            data?.map((row) => {
              const key = row[rowKey];
              const selected = selectedRowKey === key;
              return (
                <tr
                  key={key}
                  className={`vs-table__row ${selected ? 'vs-table__row--selected' : ''} ${
                    onRowClick ? 'vs-table__row--interactive' : ''
                  }`}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                >
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className={`vs-table__td vs-table__td--${col.align || 'left'}`}
                    >
                      {col.render ? col.render(row) : row[col.key]}
                    </td>
                  ))}
                </tr>
              );
            })}
        </tbody>
      </table>
      {isEmpty && (
        <div className="vs-table__empty">
          {emptyState || (
            <>
              <p className="vs-table__empty-title">Nada por aqui ainda.</p>
              <p className="vs-table__empty-desc">
                Quando houver dados, eles aparecem aqui.
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default Table;
