import React from 'react';
import './Button.css';

/**
 * VS Button — implementação de referência
 *
 * Variantes: primary | secondary | ghost | outline-cyber | danger
 * Tamanhos: sm | md (default) | lg
 *
 * REGRA DE NEGÓCIO: variant="primary" é o CTA único do viewport.
 * Não use mais de um <Button variant="primary"> visível ao mesmo tempo.
 */
export function Button({
  variant = 'secondary',
  size = 'md',
  loading = false,
  disabled = false,
  iconLeft,
  iconRight,
  type = 'button',
  children,
  ...rest
}) {
  const className = [
    'vs-button',
    `vs-button--${variant}`,
    `vs-button--${size}`,
    loading && 'vs-button--loading',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <button
      type={type}
      className={className}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...rest}
    >
      {loading ? (
        <span className="vs-button__spinner" aria-hidden="true" />
      ) : (
        <>
          {iconLeft && <span className="vs-button__icon">{iconLeft}</span>}
          <span className="vs-button__label">{children}</span>
          {iconRight && <span className="vs-button__icon">{iconRight}</span>}
        </>
      )}
    </button>
  );
}

export default Button;
