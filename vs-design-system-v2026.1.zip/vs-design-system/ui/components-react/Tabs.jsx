import React, { useState, useRef, useEffect } from 'react';
import './Tabs.css';

/**
 * VS Tabs — implementação de referência
 *
 * Acessibilidade: role tablist/tab/tabpanel, navegação por Arrow Left/Right.
 *
 * Uso:
 *   <Tabs defaultValue="leads">
 *     <Tabs.List>
 *       <Tabs.Trigger value="leads">Leads</Tabs.Trigger>
 *       <Tabs.Trigger value="vendas">Vendas</Tabs.Trigger>
 *     </Tabs.List>
 *     <Tabs.Panel value="leads">...</Tabs.Panel>
 *     <Tabs.Panel value="vendas">...</Tabs.Panel>
 *   </Tabs>
 */
const TabsContext = React.createContext(null);

export function Tabs({ defaultValue, value: controlledValue, onChange, children }) {
  const [internalValue, setInternalValue] = useState(defaultValue);
  const value = controlledValue ?? internalValue;
  const setValue = (next) => {
    if (controlledValue === undefined) setInternalValue(next);
    onChange?.(next);
  };

  return (
    <TabsContext.Provider value={{ value, setValue }}>
      <div className="vs-tabs">{children}</div>
    </TabsContext.Provider>
  );
}

function TabsList({ children }) {
  const listRef = useRef(null);
  const [indicator, setIndicator] = useState({ left: 0, width: 0 });
  const ctx = React.useContext(TabsContext);

  useEffect(() => {
    if (!listRef.current) return;
    const active = listRef.current.querySelector('[aria-selected="true"]');
    if (active) {
      setIndicator({
        left: active.offsetLeft,
        width: active.offsetWidth,
      });
    }
  }, [ctx.value]);

  const onKeyDown = (e) => {
    const triggers = Array.from(listRef.current.querySelectorAll('[role="tab"]'));
    const idx = triggers.findIndex((t) => t === document.activeElement);
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      triggers[(idx + 1) % triggers.length]?.focus();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      triggers[(idx - 1 + triggers.length) % triggers.length]?.focus();
    }
  };

  return (
    <div className="vs-tabs__list-wrapper">
      <div ref={listRef} className="vs-tabs__list" role="tablist" onKeyDown={onKeyDown}>
        {children}
        <span
          className="vs-tabs__indicator"
          style={{ left: `${indicator.left}px`, width: `${indicator.width}px` }}
          aria-hidden="true"
        />
      </div>
    </div>
  );
}

function TabsTrigger({ value, children, ...rest }) {
  const ctx = React.useContext(TabsContext);
  const selected = ctx.value === value;
  return (
    <button
      type="button"
      role="tab"
      aria-selected={selected}
      tabIndex={selected ? 0 : -1}
      className={`vs-tabs__trigger ${selected ? 'vs-tabs__trigger--active' : ''}`}
      onClick={() => ctx.setValue(value)}
      {...rest}
    >
      {children}
    </button>
  );
}

function TabsPanel({ value, children }) {
  const ctx = React.useContext(TabsContext);
  if (ctx.value !== value) return null;
  return (
    <div role="tabpanel" className="vs-tabs__panel">
      {children}
    </div>
  );
}

Tabs.List = TabsList;
Tabs.Trigger = TabsTrigger;
Tabs.Panel = TabsPanel;

export default Tabs;
