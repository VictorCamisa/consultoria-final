import React, { useId } from 'react';
import './Input.css';

/**
 * VS Input — implementação de referência
 *
 * Estados: default | error | success | disabled
 * Variantes: input (default) | textarea (via `as="textarea"`)
 */
export function Input({
  label,
  helper,
  error,
  success,
  required = false,
  as = 'input',
  prefix,
  suffix,
  id: providedId,
  className: extraClassName,
  ...rest
}) {
  const autoId = useId();
  const id = providedId || `vs-input-${autoId}`;
  const helperId = helper || error ? `${id}-helper` : undefined;

  const Tag = as;
  const state = error ? 'error' : success ? 'success' : 'default';

  const wrapperClass = [
    'vs-input-wrapper',
    `vs-input-wrapper--${state}`,
    rest.disabled && 'vs-input-wrapper--disabled',
    extraClassName,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div className="vs-input-field">
      {label && (
        <label htmlFor={id} className="vs-input-label">
          {label}
          {required && <span className="vs-input-required" aria-hidden="true"> *</span>}
        </label>
      )}
      <div className={wrapperClass}>
        {prefix && <span className="vs-input-affix">{prefix}</span>}
        <Tag
          id={id}
          className="vs-input"
          aria-invalid={error ? 'true' : undefined}
          aria-describedby={helperId}
          required={required}
          {...rest}
        />
        {suffix && <span className="vs-input-affix">{suffix}</span>}
      </div>
      {(helper || error) && (
        <p id={helperId} className={`vs-input-helper vs-input-helper--${state}`}>
          {error || helper}
        </p>
      )}
    </div>
  );
}

export default Input;
