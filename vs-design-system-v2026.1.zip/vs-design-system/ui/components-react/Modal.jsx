import React, { useEffect, useRef } from 'react';
import './Modal.css';

/**
 * VS Modal — implementação de referência
 *
 * - Backdrop com blur
 * - Foco trap básico (primeiro elemento focável)
 * - Esc fecha
 * - Restaura foco ao fechar
 */
export function Modal({
  open,
  onClose,
  title,
  eyebrow,
  children,
  footer,
  size = 'md',
  closeOnBackdrop = true,
  ...rest
}) {
  const dialogRef = useRef(null);
  const previousActiveRef = useRef(null);

  useEffect(() => {
    if (!open) return;

    previousActiveRef.current = document.activeElement;
    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.();
    };
    document.addEventListener('keydown', onKey);

    // Foca o primeiro elemento focável
    const firstFocusable = dialogRef.current?.querySelector(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    firstFocusable?.focus();

    return () => {
      document.removeEventListener('keydown', onKey);
      previousActiveRef.current?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;

  const handleBackdrop = () => {
    if (closeOnBackdrop) onClose?.();
  };

  return (
    <div className="vs-modal-backdrop" onClick={handleBackdrop} role="presentation">
      <div
        ref={dialogRef}
        className={`vs-modal vs-modal--${size}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="vs-modal-title"
        onClick={(e) => e.stopPropagation()}
        {...rest}
      >
        <button
          type="button"
          className="vs-modal__close"
          aria-label="Fechar"
          onClick={onClose}
        >
          ×
        </button>
        {eyebrow && <div className="vs-modal__eyebrow">{eyebrow}</div>}
        {title && <h2 id="vs-modal-title" className="vs-modal__title">{title}</h2>}
        <div className="vs-modal__body">{children}</div>
        {footer && <div className="vs-modal__footer">{footer}</div>}
      </div>
    </div>
  );
}

export default Modal;
