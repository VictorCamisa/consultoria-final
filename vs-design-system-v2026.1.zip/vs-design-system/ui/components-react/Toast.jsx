import React, { useEffect } from 'react';
import './Toast.css';

/**
 * VS Toast — implementação de referência (componente apresentacional)
 *
 * Variantes: info (default VS) | success | warning | error
 *
 * Em produção, combine com um provider/queue (ex: react-hot-toast, sonner)
 * mantendo apenas o estilo visual deste componente.
 */
export function Toast({
  variant = 'info',
  title,
  description,
  onClose,
  duration = 5000,
  ...rest
}) {
  useEffect(() => {
    if (!duration) return;
    const t = setTimeout(() => onClose?.(), duration);
    return () => clearTimeout(t);
  }, [duration, onClose]);

  return (
    <div
      role="status"
      aria-live="polite"
      className={`vs-toast vs-toast--${variant}`}
      {...rest}
    >
      <div className="vs-toast__content">
        {title && <p className="vs-toast__title">{title}</p>}
        {description && <p className="vs-toast__description">{description}</p>}
      </div>
      {onClose && (
        <button
          type="button"
          aria-label="Fechar"
          className="vs-toast__close"
          onClick={onClose}
        >
          ×
        </button>
      )}
    </div>
  );
}

export default Toast;
