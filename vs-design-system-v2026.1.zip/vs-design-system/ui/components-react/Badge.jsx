import React from 'react';
import './Badge.css';

/**
 * VS Badge — pílula compacta para status, categorias e contadores
 *
 * Variantes: default | cyber | success | warning | danger | solid-cyber
 */
export function Badge({ variant = 'default', children, ...rest }) {
  const className = `vs-badge vs-badge--${variant}`;
  return (
    <span className={className} {...rest}>
      {children}
    </span>
  );
}

export default Badge;
