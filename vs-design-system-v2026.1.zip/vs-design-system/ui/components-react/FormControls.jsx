import React, { useId } from 'react';
import './FormControls.css';

/**
 * VS Checkbox
 */
export function Checkbox({ label, id: providedId, ...rest }) {
  const autoId = useId();
  const id = providedId || `vs-cb-${autoId}`;
  return (
    <label htmlFor={id} className="vs-control">
      <input id={id} type="checkbox" className="vs-control__input vs-control__input--checkbox" {...rest} />
      <span className="vs-control__indicator vs-control__indicator--checkbox" aria-hidden="true" />
      {label && <span className="vs-control__label">{label}</span>}
    </label>
  );
}

/**
 * VS Radio
 */
export function Radio({ label, id: providedId, ...rest }) {
  const autoId = useId();
  const id = providedId || `vs-rd-${autoId}`;
  return (
    <label htmlFor={id} className="vs-control">
      <input id={id} type="radio" className="vs-control__input vs-control__input--radio" {...rest} />
      <span className="vs-control__indicator vs-control__indicator--radio" aria-hidden="true" />
      {label && <span className="vs-control__label">{label}</span>}
    </label>
  );
}

/**
 * VS Switch
 */
export function Switch({ label, id: providedId, ...rest }) {
  const autoId = useId();
  const id = providedId || `vs-sw-${autoId}`;
  return (
    <label htmlFor={id} className="vs-control vs-control--switch">
      <input id={id} type="checkbox" className="vs-control__input vs-control__input--switch" role="switch" {...rest} />
      <span className="vs-switch__track" aria-hidden="true">
        <span className="vs-switch__thumb" />
      </span>
      {label && <span className="vs-control__label">{label}</span>}
    </label>
  );
}

export default { Checkbox, Radio, Switch };
