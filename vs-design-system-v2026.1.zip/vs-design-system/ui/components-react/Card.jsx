import React from 'react';
import './Card.css';

/**
 * VS Card — implementação de referência
 *
 * Variantes: default | elevated | cyber | interactive
 */
export function Card({
  variant = 'default',
  eyebrow,
  title,
  subtitle,
  footer,
  children,
  as: Tag = 'div',
  ...rest
}) {
  const className = [
    'vs-card',
    `vs-card--${variant}`,
  ].join(' ');

  return (
    <Tag className={className} {...rest}>
      {eyebrow && <div className="vs-card__eyebrow">{eyebrow}</div>}
      {title && <h3 className="vs-card__title">{title}</h3>}
      {subtitle && <p className="vs-card__subtitle">{subtitle}</p>}
      {children && <div className="vs-card__body">{children}</div>}
      {footer && <div className="vs-card__footer">{footer}</div>}
    </Tag>
  );
}

export default Card;
