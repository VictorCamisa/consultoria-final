import React from 'react';
import './Dashboard.css';

/**
 * VS KPI Card — bloco de métrica para dashboards
 *
 * - O número principal pode ser destacado em Cyber Orange (highlight=true)
 *   APENAS se for o destaque único da tela.
 * - Trend opcional: { value, direction: 'up' | 'down', label }
 */
export function KPICard({
  label,
  value,
  description,
  trend,
  highlight = false,
  ...rest
}) {
  return (
    <article className="vs-kpi-card" {...rest}>
      <div className="vs-kpi-card__label">{label}</div>
      <div
        className={`vs-kpi-card__value ${highlight ? 'vs-kpi-card__value--highlight' : ''}`}
      >
        {value}
      </div>
      {description && <p className="vs-kpi-card__description">{description}</p>}
      {trend && (
        <p className={`vs-kpi-card__trend vs-kpi-card__trend--${trend.direction}`}>
          {trend.direction === 'up' ? '↑' : '↓'} {trend.value}
          {trend.label && <span className="vs-kpi-card__trend-label"> {trend.label}</span>}
        </p>
      )}
    </article>
  );
}

/**
 * VS KPI Grid — grade responsiva de 1/2/4 colunas
 */
export function KPIGrid({ children, ...rest }) {
  return (
    <div className="vs-kpi-grid" {...rest}>
      {children}
    </div>
  );
}

export default { KPICard, KPIGrid };
