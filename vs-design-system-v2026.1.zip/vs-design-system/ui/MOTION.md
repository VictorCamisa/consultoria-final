# MOTION — ANIMAÇÕES E TRANSIÇÕES

**VS Soluções · Versão 2026.1**

A VS prefere **movimento decisivo**, não orgânico. Animações são curtas, com easing forte, e servem para confirmar interação ou estabelecer hierarquia. Nunca decorativas.

---

## 1. PRINCÍPIOS

1. **Toda interação tem feedback visual.** Hover, focus, active, loading.
2. **Animações são curtas (≤ 360ms).** Mais que isso atrasa a percepção de velocidade.
3. **Easing é decisivo, não orgânico.** Preferimos snap e cubic-bezier agressivo a "bounce" suave.
4. **Sem decoração.** Nada de partículas, parallax, blur dinâmico, scroll-jacking.
5. **Respeitar `prefers-reduced-motion`.** Sempre. Já está no reset.css.

---

## 2. DURAÇÕES

| Token | Valor | Uso |
|-------|-------|-----|
| `--vs-duration-instant` | 100ms | Hover de botões/links |
| `--vs-duration-fast` | 180ms | Transições de UI básicas |
| `--vs-duration-base` | 240ms | **Padrão para a maioria** |
| `--vs-duration-slow` | 360ms | Modais, drawers |
| `--vs-duration-slower` | 500ms | Reveals de seção / animação de entrada |

---

## 3. EASINGS

| Token | Curva | Uso |
|-------|-------|-----|
| `--vs-ease-linear` | `linear` | Loading bars, progress |
| `--vs-ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` | **Padrão**: rápido início, fim suave |
| `--vs-ease-in` | `cubic-bezier(0.7, 0, 0.84, 0)` | Saída de modais |
| `--vs-ease-in-out` | `cubic-bezier(0.85, 0, 0.15, 1)` | Snap forte |
| `--vs-ease-spring` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Único easing com leve overshoot. Usar com parcimônia (badges aparecendo, toasts) |

**Regra**: 90% das transições devem usar `--vs-ease-out`.

---

## 4. PADRÕES DE INTERAÇÃO

### 4.1 Botão — hover/active/focus

```css
.vs-button {
  transition:
    background-color var(--vs-duration-fast) var(--vs-ease-out),
    transform var(--vs-duration-instant) var(--vs-ease-out),
    box-shadow var(--vs-duration-fast) var(--vs-ease-out);
}

.vs-button:hover {
  background-color: var(--vs-cyber-hover); /* #E64A00 */
}

.vs-button:active {
  transform: scale(0.98);
  background-color: var(--vs-cyber-active); /* #CC4200 */
}

.vs-button:focus-visible {
  box-shadow: var(--vs-shadow-cyber); /* glow laranja */
}
```

### 4.2 Card — hover

```css
.vs-card {
  transition:
    background-color var(--vs-duration-base) var(--vs-ease-out),
    border-color var(--vs-duration-base) var(--vs-ease-out),
    transform var(--vs-duration-base) var(--vs-ease-out);
}

.vs-card:hover {
  background-color: var(--vs-surface-3);
  border-color: var(--vs-border-strong);
  transform: translateY(-2px);
}
```

### 4.3 Modal — entrada

```css
@keyframes vs-modal-enter {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(8px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

.vs-modal {
  animation: vs-modal-enter var(--vs-duration-slow) var(--vs-ease-out);
}

.vs-modal-backdrop {
  animation: vs-fade-in var(--vs-duration-base) var(--vs-ease-out);
}
```

### 4.4 Toast — entrada (com spring)

```css
@keyframes vs-toast-enter {
  from {
    opacity: 0;
    transform: translateX(24px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.vs-toast {
  animation: vs-toast-enter var(--vs-duration-base) var(--vs-ease-spring);
}
```

### 4.5 Tabs — indicator slide

O indicador da tab ativa desliza horizontalmente:

```css
.vs-tab-indicator {
  transition:
    left var(--vs-duration-base) var(--vs-ease-in-out),
    width var(--vs-duration-base) var(--vs-ease-in-out);
}
```

### 4.6 Skeleton loader

Gradiente animado em loop suave.

```css
@keyframes vs-skeleton-shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

.vs-skeleton {
  background: linear-gradient(
    90deg,
    var(--vs-surface) 25%,
    var(--vs-surface-3) 50%,
    var(--vs-surface) 75%
  );
  background-size: 200% 100%;
  animation: vs-skeleton-shimmer 1.6s var(--vs-ease-linear) infinite;
}
```

### 4.7 Spinner / loading

Rotação contínua, sem easing.

```css
@keyframes vs-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.vs-spinner {
  animation: vs-spin 800ms linear infinite;
}
```

### 4.8 Reveal on scroll (entrada de seção)

```css
@keyframes vs-reveal {
  from {
    opacity: 0;
    transform: translateY(24px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.vs-reveal {
  animation: vs-reveal var(--vs-duration-slower) var(--vs-ease-out) both;
}

/* Stagger children: aplicar animation-delay incremental */
.vs-reveal-stagger > *:nth-child(1) { animation-delay: 0ms; }
.vs-reveal-stagger > *:nth-child(2) { animation-delay: 80ms; }
.vs-reveal-stagger > *:nth-child(3) { animation-delay: 160ms; }
.vs-reveal-stagger > *:nth-child(4) { animation-delay: 240ms; }
```

---

## 5. KEYFRAMES PRONTOS (copiar para projeto)

```css
@keyframes vs-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes vs-fade-out {
  from { opacity: 1; }
  to { opacity: 0; }
}

@keyframes vs-slide-up {
  from { opacity: 0; transform: translateY(16px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes vs-slide-down {
  from { opacity: 0; transform: translateY(-16px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes vs-slide-left {
  from { opacity: 0; transform: translateX(16px); }
  to { opacity: 1; transform: translateX(0); }
}

@keyframes vs-pulse-cyber {
  0%, 100% { box-shadow: 0 0 0 0 var(--vs-cyber-glow); }
  50% { box-shadow: 0 0 0 8px transparent; }
}
```

---

## 6. O QUE NÃO FAZER

- ❌ Animação > 500ms para qualquer transição comum.
- ❌ Easing tipo `ease-in-out` padrão do CSS (lerdo demais).
- ❌ Bounce excessivo (`cubic-bezier` com overshoot > 1.6).
- ❌ Parallax em scroll.
- ❌ Scroll-jacking ou scroll-snap forçado em landing comercial.
- ❌ Animação contínua decorativa (gradiente girando, partículas flutuando).
- ❌ Hover effects em mobile (não há hover, e force "tap-highlight" parece bug).

---

## 7. CHECKLIST DE MOTION

- [ ] Toda transição usa um token de duração? (sem `200ms` arbitrário)
- [ ] Easing é `--vs-ease-out` por padrão?
- [ ] Animações ≤ 360ms?
- [ ] Botões respondem a hover, active e focus?
- [ ] CTA primário tem glow Cyber Orange em focus?
- [ ] `prefers-reduced-motion` é respeitado? (já está no reset)
- [ ] Não há animação contínua decorativa?
