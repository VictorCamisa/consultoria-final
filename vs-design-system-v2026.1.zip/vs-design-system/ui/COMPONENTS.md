# COMPONENTS — SPECIFICAÇÃO INDUSTRIAL

**VS Soluções · Versão 2026.1**

Cada componente abaixo é especificado com: anatomia, variantes, estados, acessibilidade, tokens usados, exemplo React + CSS puro. Implementações de referência estão em `components-react/`.

---

## ÍNDICE

1. [Button](#1-button)
2. [Card](#2-card)
3. [Input / Textarea](#3-input--textarea)
4. [Select](#4-select)
5. [Checkbox / Radio / Switch](#5-checkbox--radio--switch)
6. [Badge](#6-badge)
7. [Tabs](#7-tabs)
8. [Modal](#8-modal)
9. [Toast](#9-toast)
10. [Table](#10-table)
11. [Dashboard / KPI Card](#11-dashboard--kpi-card)
12. [Section Header](#12-section-header)
13. [Navigation (header + sidebar)](#13-navigation)

---

## 1. BUTTON

### Anatomia
`[ícone opcional] [label] [ícone opcional]` — padding interno, border-radius 8px, fonte Montserrat 600.

### Variantes
| Variante | Background | Texto | Border | Uso |
|----------|------------|-------|--------|-----|
| `primary` | `--vs-cyber-orange` | `--vs-text-on-cyber` (preto) | none | **Único CTA por viewport** |
| `secondary` | transparent | `--vs-text-primary` | `--vs-border-default` | Ações secundárias |
| `ghost` | transparent | `--vs-text-primary` | none | Ações terciárias, links |
| `outline-cyber` | transparent | `--vs-cyber-orange` | `1px solid #FF5300` | Alternativa ao primary quando há outro destaque |
| `danger` | `--vs-danger` | white | none | Ações destrutivas |

### Tamanhos
| Tamanho | Altura | Padding horizontal | Font-size |
|---------|--------|-------------------:|----------:|
| `sm` | 32px | 12px | 13px |
| `md` (padrão) | 40px | 20px | 14px |
| `lg` | 48px | 28px | 16px |

### Estados
- `default`, `hover`, `active`, `focus-visible`, `disabled`, `loading`
- **Loading**: substitui o conteúdo por spinner, mantém largura.
- **Disabled**: `opacity: 0.5`, `cursor: not-allowed`.
- **Focus**: outline removido, `box-shadow: 0 0 0 3px rgba(255,83,0,.35)`.

### Acessibilidade
- Sempre `<button>` nativo (ou `<a role="button">` se for link).
- `aria-disabled` quando disabled.
- `aria-busy="true"` quando loading.
- Foco visível obrigatório.

---

## 2. CARD

### Anatomia
Container com background `--vs-surface`, border 1px `--vs-border`, radius 12px, padding 24px (mobile: 16px).

### Estrutura interna
```
┌─────────────────────────────┐
│ [eyebrow / section header]  │  ← opcional, mono caixa alta
│                             │
│ [Title — Poppins Black]     │  ← obrigatório
│ [Subtitle — Montserrat]     │  ← opcional
│                             │
│ [Body content]              │
│                             │
│ [Footer / actions]          │  ← opcional
└─────────────────────────────┘
```

### Variantes
- `default` — surface padrão
- `elevated` — surface-2, com sombra md
- `cyber` — borda Cyber Orange (`--vs-border-cyber`), para destaque único na tela
- `interactive` — adiciona hover state (translateY -2px, surface-3)

### Estados
- `default`, `hover` (se interactive), `focus-within` (se contém input)

---

## 3. INPUT / TEXTAREA

### Anatomia
Label acima, input com padding interno 12px 16px, height 40px (input) ou variável (textarea), radius 8px.

### Estrutura
```
Label *                    ← Montserrat 500, 13px, color secondary
[ Input field           ]  ← background surface, border 1px border-default
Helper text                ← 13px, color tertiary
```

### Variantes
- `default` — neutro
- `success` — borda verde sutil
- `error` — borda danger, helper em danger
- `with-prefix` / `with-suffix` — ícone à esquerda/direita

### Estados
- `default`, `hover` (border mais forte), `focus` (border Cyber Orange + shadow-cyber), `disabled`, `readonly`, `error`

### Tipografia
- Input: Montserrat 400, 14px
- Placeholder: `--vs-text-tertiary`

### Acessibilidade
- `<label>` sempre associado via `htmlFor`/`id`.
- Erro em `aria-describedby`.
- `aria-invalid="true"` quando em erro.

---

## 4. SELECT

Mesma anatomia de Input. Trigger custom com seta à direita, dropdown abre com animação `vs-slide-down`, opções com hover `--vs-surface-3`, opção selecionada com checkmark Cyber Orange à esquerda.

### Acessibilidade
- Use `<select>` nativo em mobile.
- Em desktop, custom dropdown com `role="listbox"`, `aria-expanded`, navegação por teclado (Arrow Up/Down, Enter, Esc).

---

## 5. CHECKBOX / RADIO / SWITCH

### Checkbox
- 18px × 18px, border-radius 4px, border 1.5px `--vs-border-strong`.
- Checked: background Cyber Orange, checkmark branco.
- Focus: shadow-cyber.

### Radio
- 18px × 18px, border-radius 50%.
- Checked: dot interno Cyber Orange (8px × 8px).

### Switch
- Track: 36px × 20px, border-radius 9999px, background `--vs-border-strong`.
- Thumb: 16px × 16px, branco, transição `--vs-duration-fast`.
- Checked: track Cyber Orange, thumb desliza para direita.

---

## 6. BADGE

### Anatomia
Pílula pequena, padding 4px 10px, border-radius 9999px, font-size 12px Montserrat 600 caixa alta tracking 0.05em.

### Variantes
| Variante | Background | Texto |
|----------|------------|-------|
| `default` | `--vs-surface-3` | `--vs-text-secondary` |
| `cyber` | `--vs-cyber-soft` | `--vs-cyber-orange` |
| `success` | `--vs-success-soft` | `--vs-success` |
| `warning` | `--vs-warning-soft` | `--vs-warning` |
| `danger` | `--vs-danger-soft` | `--vs-danger` |
| `solid-cyber` | `--vs-cyber-orange` | `--vs-text-on-cyber` |

---

## 7. TABS

### Anatomia
Lista horizontal, cada tab com padding 12px 16px, font-size 14px Montserrat 500. Indicador inferior 2px que desliza.

### Estados
- `default`: texto `--vs-text-secondary`
- `hover`: texto `--vs-text-primary`
- `active`: texto `--vs-text-primary`, indicator Cyber Orange
- `disabled`: opacity 0.4

### Acessibilidade
- `role="tablist"` / `role="tab"` / `role="tabpanel"`.
- `aria-selected` na tab ativa.
- Navegação por Arrow Left/Right.

---

## 8. MODAL

### Anatomia
- **Backdrop**: full-screen, `rgba(5, 8, 20, 0.7)`, `backdrop-filter: blur(4px)`.
- **Container**: max-width 560px (default), centralizado, background `--vs-surface-2`, border-radius 16px, padding 32px, sombra xl.
- **Botão close**: top-right, 32×32px, ícone X.
- **Animação entrada**: scale 0.96 → 1 + opacity 0 → 1, duração `--vs-duration-slow`.

### Estrutura
```
[X close]
[Eyebrow opcional]
[Title — Poppins Black 28px]
[Body]
[Footer com botões: secondary à esquerda + primary à direita]
```

### Acessibilidade
- `role="dialog"`, `aria-modal="true"`, `aria-labelledby` apontando para título.
- Foco trap (não sai do modal por Tab).
- Esc fecha o modal.
- Restaura foco ao elemento anterior ao fechar.

---

## 9. TOAST

### Anatomia
Card flutuante 360px, padding 16px, border-radius 12px, sombra lg. Posição fixa: bottom-right (desktop) ou top-center (mobile).

### Variantes
| Variante | Border-left | Ícone |
|----------|-------------|-------|
| `info` | Cyber Orange (default VS) | i |
| `success` | `--vs-success` | check |
| `warning` | `--vs-warning` | ! |
| `error` | `--vs-danger` | x |

### Border-left
4px sólido, na cor da variante. Resto do card em `--vs-surface-2`.

### Animação
Entrada: spring (`--vs-ease-spring`), translateX 24px → 0.
Auto-dismiss: 5s default, com barra de progresso opcional na base.

---

## 10. TABLE

### Anatomia
- Header: background `--vs-surface`, font Montserrat 600 caixa alta tracking 0.05em, font-size 12px.
- Linha: padding 16px 20px, border-bottom 1px `--vs-border`.
- Hover: background `--vs-surface-3`.
- Linha selecionada: background `--vs-cyber-soft`, border-left 3px Cyber Orange.

### Recursos
- Sortable columns: ícone seta ao hover, seta laranja na coluna ativa.
- Pagination: rodapé com "1–10 de 247", botões prev/next em ghost.
- Empty state: ilustração simples + headline + CTA.
- Loading: skeleton rows.

### Responsividade
Em mobile (<768px), tabelas viram **cards verticais** ou habilita scroll horizontal com gradiente de fade nas bordas.

---

## 11. DASHBOARD / KPI CARD

### KPI Card
```
┌────────────────────────┐
│ LABEL EM CAIXA ALTA    │  ← 12px, mono, secondary
│                        │
│ 2.847                  │  ← 48px, Poppins Black, branco OU laranja
│ Leads capturados       │  ← 14px, regular, secondary
│                        │
│ ↑ +12% vs mês anterior │  ← 13px, success ou danger
└────────────────────────┘
```

- Padding: 24px
- Background: `--vs-surface`
- Border-radius: 12px
- O número principal pode ser Cyber Orange **se for o destaque único** da tela.

### Grid de KPIs
- Desktop: 4 colunas
- Tablet: 2 colunas
- Mobile: 1 coluna

---

## 12. SECTION HEADER

Padrão visual de "— 03 / PALETA":

```
— 03 / PALETA              ← mono / Montserrat 500, caixa alta, tracking 0.1em, 14px, Cyber Orange
                              precedido de em-dash + espaço

Três cores.                 ← Poppins Black Italic, 48px, branco
Zero ambiguidade.           ← (segunda linha pode ter palavras-chave em Cyber Orange)
```

### Markup React
```jsx
<header className="vs-section-header">
  <span className="vs-section-eyebrow">— 03 / PALETA</span>
  <h2 className="vs-headline">
    Três cores. <span className="vs-highlight">Zero ambiguidade.</span>
  </h2>
</header>
```

---

## 13. NAVIGATION

### Header (top nav)
- Altura: 64px
- Background: `--vs-deep-space` com border-bottom `--vs-border`
- Layout: `[logo] ........ [nav links] ........ [CTA secondary] [CTA primary]`
- Mobile: logo + hamburger; menu abre como drawer lateral

### Sidebar (dashboard)
- Largura: 240px (collapsed: 64px)
- Background: `--vs-surface`
- Border-right: 1px `--vs-border`
- Item ativo: border-left 3px Cyber Orange, background `--vs-cyber-soft`
- Item hover: background `--vs-surface-3`

---

## REGRAS GERAIS DE COMPONENTES

1. **Todo componente respeita os tokens.** Nunca cor/espaçamento hardcoded.
2. **Todo componente tem `:focus-visible` com glow Cyber Orange.**
3. **Todo componente respeita `prefers-reduced-motion`.**
4. **Todo componente é acessível via teclado.**
5. **Todo componente tem estado disabled/loading quando aplicável.**
6. **CTA primário aparece UMA VEZ por viewport.**

Implementações React + CSS puro de cada componente estão em `components-react/`.
