# LOGO USAGE — O MONOGRAMA VS

**VS Soluções · Versão 2026.1**

Não há símbolo, ícone ou pictograma. **O monograma VS é a marca completa.**

Toda a força visual da marca nasce de duas decisões: (1) a tipografia escolhida (Poppins Black Italic 900) e (2) a relação cromática entre V e S (branco/preto + Cyber Orange).

---

## CONSTRUÇÃO TIPOGRÁFICA

| Atributo | Valor |
|----------|-------|
| **Fonte** | Poppins |
| **Peso** | Black (900) |
| **Estilo** | Italic |
| **Tracking entre V e S** | -2.5% (`-0.025em`) |
| **Cor do V (padrão)** | Branco `#FFFFFF` |
| **Cor do S (padrão)** | Cyber Orange `#FF5300` |
| **Cor do V (modo claro)** | Preto `#000000` ou Deep Space `#050814` |

---

## VARIAÇÕES APROVADAS

### 1. Primária — Fundo escuro (padrão)
- **Background**: Deep Space Blue `#050814`
- **V**: Branco `#FFFFFF`
- **S**: Cyber Orange `#FF5300`
- **Uso**: 90% das aplicações. Default sempre que possível.
- **Arquivo**: `assets/logo-vs-dark.svg`

### 2. Secundária — Fundo claro
- **Background**: Branco `#FFFFFF`
- **V**: Preto `#000000` ou Deep Space `#050814`
- **S**: Cyber Orange `#FF5300`
- **Uso**: e-mails transacionais, documentos impressos, anexos PDF de uso interno.
- **Arquivo**: `assets/logo-vs-light.svg`

### 3. Terciária — Fundo Cyber Orange
- **Background**: Cyber Orange `#FF5300`
- **V**: Branco `#FFFFFF`
- **S**: Deep Space Blue `#050814` ou Preto `#000000`
- **Uso**: peças de campanha, banners de destaque, capas de redes sociais.
- **Arquivo**: `assets/logo-vs-cyber.svg`

### 4. Com tagline
- Monograma + linha "VENDAS DE SOLUÇÕES" abaixo, em Montserrat 500/600, caixa alta, tracking 0.30em.
- Espaçamento entre monograma e tagline: 24px (digital) / 8mm (impresso).
- **Arquivo**: `assets/logo-vs-tagline.svg`

---

## TAMANHOS MÍNIMOS

| Mídia | Mínimo absoluto |
|-------|-----------------|
| **Digital** | 24px de altura |
| **Impressão** | 8mm de altura |

Abaixo desses valores, o itálico perde legibilidade e a hierarquia cromática V/S fica imperceptível.

### Tamanhos recomendados por aplicação

| Aplicação | Altura recomendada |
|-----------|---------------------|
| Favicon | 32px (versão simplificada, sem tagline) |
| Header de site/app | 32–40px |
| Email — header | 40–56px |
| Card de apresentação | 80–120px |
| Hero de landing page | 120–200px |
| Capa de deck | 180–280px |
| Outdoor / banner físico | mínimo 30cm de altura |

---

## ÁREA DE PROTEÇÃO (CLEAR SPACE)

A área livre mínima ao redor do monograma equivale a **50% da altura do logo** (`clearSpace: 0.5`).

```
   ┌─ 0.5h ─┐
0.5h   VS   0.5h
   └─ 0.5h ─┘
```

Nenhum elemento — texto, ícone, borda, imagem — pode invadir essa área.

---

## O QUE NUNCA FAZER COM O LOGO

- ❌ **Nunca** rotacionar o monograma (ele já é itálico — qualquer rotação adicional descaracteriza).
- ❌ **Nunca** usar o V e o S separados como ícones independentes em aplicação institucional.
- ❌ **Nunca** alterar a cor do V para qualquer cor que não seja branco, preto ou Deep Space.
- ❌ **Nunca** alterar a cor do S para qualquer cor que não seja Cyber Orange (exceto na variação terciária, onde S vira escuro sobre fundo laranja).
- ❌ **Nunca** aplicar gradiente, sombra projetada, contorno, brilho ou efeito 3D.
- ❌ **Nunca** colocar o monograma sobre fotografia ou imagem complexa sem container sólido por trás.
- ❌ **Nunca** alongar, comprimir ou distorcer as proporções.
- ❌ **Nunca** usar Poppins em peso diferente de 900 ou estilo diferente de Italic no monograma.
- ❌ **Nunca** reduzir abaixo de 24px digital ou 8mm impresso.

---

## SOBRE FOTOGRAFIA OU FUNDO COMPLEXO

Quando precisar aplicar o logo sobre uma foto ou fundo não-uniforme:

1. **Primeira opção**: aplicar um container sólido em Deep Space Blue por trás do logo, com border-radius 12–16px e padding mínimo igual ao clear space.
2. **Segunda opção**: aplicar um overlay escuro de pelo menos 70% sobre toda a foto antes do logo.
3. **Nunca**: aplicar o logo direto sobre foto sem overlay nem container.

---

## FAVICON E ÍCONES DE APP

Para favicon e ícones em tamanhos muito pequenos (16–48px), é permitida uma versão simplificada:

- **VS** sem tagline.
- Tracking pode ser ajustado para 0% (em vez de -2.5%) para evitar sobreposição em pixels pequenos.
- A relação cromática V branco / S laranja deve ser preservada.
- Container quadrado opcional em Deep Space com `border-radius: 20%`.

---

## CHECKLIST DE APLICAÇÃO DO LOGO

Antes de publicar qualquer peça com o monograma VS:

- [ ] Está em uma das três variações aprovadas (dark, light, cyber)?
- [ ] Tipografia é Poppins Black Italic 900?
- [ ] V está em branco/preto e S em Cyber Orange (ou inversão na variação cyber)?
- [ ] Tamanho ≥ 24px digital / 8mm impresso?
- [ ] Clear space respeitado (≥ 50% da altura)?
- [ ] Nenhum efeito (sombra, gradiente, contorno, 3D)?
- [ ] Sobre foto/fundo complexo? Tem container sólido ou overlay 70%+?
- [ ] Não foi rotacionado nem distorcido?

Se qualquer resposta for "não", a peça precisa ser corrigida antes de publicar.
