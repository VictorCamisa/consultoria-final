# BRAND VOICE — TOM DE VOZ E LINGUAGEM

**VS Soluções · Versão 2026.1**

A linguagem VS é **agressiva, mas profissional**. Foco em resultado, dominação de nicho, e clareza brutal. Nunca floreio. Nunca jargão vazio. Nunca infantilização do cliente.

---

## OS QUATRO VETORES DA FALA VS

### 01. Direta
Frases curtas. Sujeito + verbo + objeto. Se uma palavra pode ser cortada sem perder sentido, ela é cortada.

| ❌ Genérico | ✅ VS |
|------------|------|
| "Buscamos otimizar e potencializar a sua estrutura comercial através de soluções inovadoras." | "Substituímos seu departamento comercial." |
| "Oferecemos uma plataforma robusta que visa transformar a maneira como você se relaciona com seus clientes." | "Você responde leads em 30 minutos. A gente responde em 1." |

### 02. Orientada a resultado
Fala em números, em conversões, em economia. Nunca em "transformação digital" abstrata.

| ❌ Genérico | ✅ VS |
|------------|------|
| "Geramos valor sustentável para o seu negócio." | "R$48k recuperados em 30 dias." |
| "Sua empresa vai alcançar um novo patamar de performance." | "16% mais venda que vendedor humano. 98,9% de assertividade." |

### 03. Confrontadora quando precisa
Não tem medo de apontar o problema do cliente. Se o lead demora 30 minutos para ser respondido, dizemos: **"Você está perdendo 21x mais vendas do que poderia."** A linguagem confronta o gap e mostra o caminho.

| ❌ Genérico | ✅ VS |
|------------|------|
| "Que tal melhorar seu tempo de resposta?" | "Lead que demora mais de 5 minutos para ser respondido vale 21x menos. Você está jogando dinheiro fora." |
| "Automatize seu atendimento." | "Você não precisa de mais gente. Precisa parar de perder lead na madrugada." |

### 04. Humana, não robótica
Apesar de tecnológica, a VS é operada por pessoas. A copy nunca esconde isso. Use **"nós", "a gente", "você"**. Não use "a empresa entende" ou "a plataforma sugere".

| ❌ Robótico | ✅ Humano |
|------------|----------|
| "A plataforma identifica leads qualificados." | "A gente filtra os leads bons antes de chegarem em você." |
| "O sistema sugere a próxima ação." | "Você abre o dashboard e vê quem precisa de atenção agora." |

---

## TAGLINES OFICIAIS

### Tagline corporativa (institucional)
> **VENDAS DE SOLUÇÕES**

Sempre em CAIXA ALTA, tracking 0.25–0.30em, em Montserrat 500/600.

### Taglines de produto/posicionamento

- "Vendas de Soluções. Substituímos seu departamento comercial."
- "Ecossistemas digitais que substituem departamentos."
- "A gente não vende software. Vende resultado."
- "Sua operação comercial automatizada. Sem agência. Sem SaaS de prateleira."

### Taglines situacionais (vertical)

- **Auto**: "Mais carro vendido. Menos lead perdido."
- **Estética**: "Conversão 7,4% no nicho onde a média é 1%."
- **Imob**: "Imobiliária que responde em 1 minuto vende 21x mais."
- **Odonto/Advocacia**: "Atendimento humano. Velocidade de máquina."

---

## VOCABULÁRIO

### ✅ Palavras-marca (use)

- **Ecossistema** — não "plataforma" nem "ferramenta"
- **Operação** — não "serviço" nem "solução genérica"
- **Domínio / dominação de nicho** — não "liderança" genérica
- **Substituir** — não "complementar" nem "auxiliar"
- **Acelerar** — não "otimizar" nem "melhorar"
- **Arquitetura** — não "estrutura" nem "configuração"
- **Garra** — quando descrevendo o time
- **Resultado** — sempre que possível, antes de "performance"

### ❌ Palavras proibidas (nunca use)

- "Soluções inovadoras"
- "Transformação digital"
- "Sinergia"
- "Disruptivo" (sem contexto concreto)
- "Empoderar"
- "Jornada" (no sentido marketingueiro)
- "Curadoria"
- "Experiência mágica" / "encantar"
- "Resolver dores" (substitua por verbo concreto)
- "Inteligência de ponta a ponta"
- "Customizado" (use "sob medida" ou "específico para seu nicho")

### ⚠️ Use com cautela

- **IA / inteligência artificial** — só quando concreto. Prefira "agente de WhatsApp", "qualificador automático", "modelo Claude treinado". Evite "IA" como buzzword vazio.
- **Premium** — só quando justificado pelo preço/contexto. Nunca decorativo.
- **Best-in-class / world-class** — não temos pretensão internacional na copy. Use "líder do nicho" ou "melhor solução pra X em Y".

---

## ESTRUTURAS DE COPY RECORRENTES

### Headline em três tempos: confrontar → quantificar → propor

```
[Problema do cliente, em 1 frase]
[Número que prova o tamanho do problema]
[Promessa concreta da VS]
```

**Exemplo:**
> Lead novo levando 30 minutos pra ser respondido.
> Vale 21x menos do que se respondesse em 5.
> A gente responde em 1.

### CTA — sempre verbo + benefício concreto

| ❌ Vago | ✅ VS |
|--------|------|
| "Saiba mais" | "Ver como funciona" |
| "Entrar em contato" | "Agendar diagnóstico" |
| "Comprar agora" | "Começar em 7 dias" |
| "Cadastre-se" | "Pegar a primeira análise" |

### Provas sociais — sempre com número

```
[Métrica auditável]
[O que ela significa em linguagem do cliente]
```

**Exemplo:**
> 180.000 mensagens enviadas pela IA da VS em produção.
> Cada uma respondida em menos de 1 minuto.

### Escassez ética — só quando real

Use escassez **só** quando ela existe de verdade (ex.: "5 vagas no programa de janeiro" só se forem 5 vagas reais). Nunca "últimas 3 horas!" se a oferta segue na semana seguinte. A marca confronta o cliente — não o engana.

---

## LONG-FORM (e-mail, blog, landing extensa)

### Estrutura de e-mail comercial VS

1. **Linha de assunto**: pergunta direta ou número impactante. Máx. 60 caracteres.
   - ✅ "Quanto você perdeu de venda essa semana?"
   - ✅ "R$48k recuperados em 30 dias — assim:"
   - ❌ "Conheça nossas soluções inovadoras"

2. **Primeira frase**: nunca cumprimento genérico. Vai direto.
   - ✅ "Olha, vou ser direto: você está perdendo lead na madrugada."
   - ❌ "Espero que esteja tudo bem por aí!"

3. **Corpo**: 3 parágrafos curtos. Cada um com uma ideia.
   - Parágrafo 1: o problema com número.
   - Parágrafo 2: o que a VS fez por outro cliente parecido.
   - Parágrafo 3: a oferta concreta + CTA único.

4. **CTA**: um link único. Botão Cyber Orange se for HTML.

5. **Assinatura**: nome + cargo + WhatsApp. Sem "Atenciosamente". Sem postscript marketingueiro.

### Estrutura de landing page VS

```
[Hero]
  Headline em 3 tempos (confrontar / quantificar / propor)
  Subheadline com 1 prova concreta
  CTA primário (Cyber Orange)
  CTA secundário (texto link)

[Prova social — números]
  3 métricas reais em destaque

[Como funciona]
  3-4 passos numerados, frases curtas

[Cases]
  2-3 cases com nome, vertical, métrica antes/depois

[Quem é a VS]
  1 parágrafo curto. Empresa familiar, dominação de nicho.

[CTA final]
  Reforço do CTA primário
```

---

## REGRAS GERAIS DE PUNCTUAÇÃO E FORMATO

- **Frases curtas**. Máx. 20 palavras por frase em copy de marketing.
- **Parágrafos curtos**. Máx. 3 frases por parágrafo em copy.
- **Negrito** apenas para **um destaque** por parágrafo. Nunca grifar frases inteiras.
- **Itálico** raramente — só para títulos de obras citadas ou termos estrangeiros não-aclimatados.
- **Caixa alta** apenas em taglines, títulos de seção ("— 03 / PALETA"), e siglas. Nunca em frases inteiras de copy.
- **Travessões** (—) com espaço dos dois lados — funcionam como aceleradores de leitura. Use sem medo.
- **Números**: sempre em algarismos quando ≥ 10 ou em métricas (`R$ 48.000`, `21x`, `98,9%`). Em português use **vírgula decimal** (`98,9%`, não `98.9%`).
- **Moeda**: `R$ 48.000` ou `R$48k` em contextos casuais. Nunca `48.000 reais` em copy de marketing.

---

## CHECKLIST DE COPY VS

Antes de publicar qualquer texto em nome da VS:

- [ ] Tem ao menos um número concreto?
- [ ] Está em frases curtas (≤20 palavras)?
- [ ] Confronta um problema real do cliente?
- [ ] Não usa nenhuma palavra proibida?
- [ ] CTA é verbo + benefício concreto?
- [ ] Tom é direto, não corporativo?
- [ ] "Nós/a gente/você" estão presentes?
- [ ] Cabe num WhatsApp ou num post de LinkedIn sem trair o formato?

Se alguma resposta for "não", o texto não está pronto.
