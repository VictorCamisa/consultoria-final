# SEMIÓTICA — O QUE V E S SIGNIFICAM

**VS Soluções · Versão 2026.1**

O monograma VS não é arbitrário. As duas letras carregam papéis semânticos opostos e complementares — e a relação entre elas é o que constrói a narrativa visual da marca.

---

## V — A FUNDAÇÃO

- **Cor**: Branco (em fundo escuro) ou Preto (em fundo claro). Cor neutra, ancorada.
- **Significado**: **Vendas · Visão · Estrutura.**
- **Papel narrativo**: a base sólida, a transparência tecnológica, a engenharia que sustenta a operação.

> **O "V" é o que não pode falhar.**

Visualmente, o V é desenhado em Poppins Black Italic 900 com inclinação que cria uma diagonal descendente — sustentação que se prepara para subir. É a metade "estrutural" da marca: a engenharia, a infraestrutura, o backend, a parte que o cliente não vê mas que faz tudo funcionar.

---

## S — A SOLUÇÃO

- **Cor**: Cyber Orange `#FF5300`. Cor que brilha e age.
- **Significado**: **Soluções · Garra · Diferencial.**
- **Papel narrativo**: o diferencial humano, a paixão da equipe, o resultado entregue.

> **O "S" é o que faz o cliente lembrar.**

O S em Cyber Orange é a metade "experiencial" da marca: o frontend, o atendimento, o resultado tangível, a conversão. É o que aparece nos números do dashboard, na mensagem que chega no WhatsApp, no fechamento da venda.

---

## A CONEXÃO

O design prevê integração sutil entre as letras — o itálico cria continuidade visual, e a proximidade entre V e S simboliza que **vendas e tecnologia não são duas coisas, são a mesma coisa**.

Essa é a tese central da VS: **não vendemos software, vendemos resultado comercial automatizado.**

> "V sustenta. S resolve. Juntas, são uma operação."

---

## REGRAS DE USO SEMÂNTICO

### Quando comunicar o V isoladamente
- Documentos técnicos, infraestrutura, segurança, arquitetura.
- Conteúdo voltado a desenvolvedores, parceiros técnicos, auditoria.
- Tom: confiável, estável, transparente.

### Quando comunicar o S isoladamente
- Cases de venda, dashboards de resultado, depoimentos de cliente.
- Conteúdo voltado a gestores comerciais, donos de PME, decisores.
- Tom: agressivo, energético, focado em conversão.

### Quando comunicar V + S juntos (padrão)
- Tudo o resto. Marca institucional, landing principal, deck comercial.
- O monograma completo é a forma padrão.

---

## NARRATIVA EM 3 NÍVEIS

### Nível 1 — O nome
**VS** = **Vendas de Soluções.** Significado literal, declarado.

### Nível 2 — A semiótica
**V** = a engenharia que sustenta. **S** = o resultado que vende.

### Nível 3 — A tese
**Vendas e tecnologia não são duas áreas. São a mesma operação.** A VS existe para provar isso na prática, em PMEs brasileiras, todo dia.
