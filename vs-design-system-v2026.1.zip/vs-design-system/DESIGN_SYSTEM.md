# DESIGN SYSTEM — DOCUMENTO MESTRE

**VS Soluções · Versão 2026.1 · Era Cyber Orange**

---

## 1. POSICIONAMENTO ESTRATÉGICO

A VS Soluções **não é fornecedora — é arquiteta de ecossistemas digitais**. A marca representa uma empresa que constrói e opera arquiteturas de tecnologia que conectam captura de lead, qualificação por IA, follow-up automatizado, gestão financeira, prova social e dashboards de comando em uma única operação.

**O cliente VS não compra ferramenta. Compra operação.**

### Os quatro pilares da marca

1. **Dominação de nicho, não generalismo** — escolhemos verticais (Auto, Estética, Imob, Odonto, Advocacia) e dominamos cada uma com produto específico.
2. **Inteligência de dados como diferencial** — toda decisão é orientada por dados; o cliente vê ROI em tempo real.
3. **Velocidade como cultura, não como evento** — Lovable + Supabase + Claude API + Evolution API permitem lançar produto em dias.
4. **Empresa familiar, mentalidade de império** — bootstrapped, sem investidor, ambição de longo prazo. Sólida na base, agressiva na superfície.

### As três métricas que comunicam a marca

- **2.500+** leads processados pelos ecossistemas VS
- **180k+** mensagens disparadas via IA em produção
- **98,9%** assertividade de vendas vs. tráfego puro

> Sempre que um número for usado em copy, prefira números reais e auditáveis.

---

## 2. POR QUE MUDAMOS DA ERA AZUL NEON

A versão anterior — azul neon, arquitetura corporativa fria — cumpriu o papel de validar a marca enquanto a operação se estabilizava. Mas a empresa que executa hoje (cinco clientes ativos, R$15k líquidos recorrentes, dois ativos de produto, ICP definido) não é mais a empresa daquela identidade.

**Três tensões que o sistema antigo não resolvia:**

1. **Diferenciação visual em mercado saturado** — toda agência B2B brasileira usa azul. Cyber Orange é a decisão deliberada de não se parecer com a concorrência.
2. **Coerência com o produto real** — a VS substitui departamentos. Azul neon comunicava neutralidade; Cyber Orange comunica decisão.
3. **Escalabilidade digital** — flat design, alto contraste, fundo escuro renderizam igual em mobile, dashboard, deck e landing.

> "O rebranding não é estético. É uma decisão estratégica para alinhar a percepção da marca com a realidade da operação — e com a ambição dos próximos 36 meses."

---

## 3. PALETA — THE TECH FUSION

### Três cores. Zero ambiguidade.

A paleta é restrita por decisão. Cada cor tem função semântica clara — nenhuma é ornamental.

| Cor | HEX | RGB | Função semântica | Uso |
|-----|-----|-----|------------------|-----|
| **Deep Space Blue** | `#050814` | `5, 8, 20` | Fundação, segurança cibernética, estabilidade | Background dominante de todas as superfícies |
| **Cyber Orange** | `#FF5300` | `255, 83, 0` | Garra, paixão, motor de aceleração | CTAs, links, destaques, números-chave |
| **Branco Puro** | `#FFFFFF` | `255, 255, 255` | Respiro, clareza, fundação tipográfica | Texto principal, monograma "V" |

### Regra de proporção 70/20/10

- **70%** Deep Space Blue (background, superfícies, cards)
- **20%** Branco Puro (texto, ícones funcionais, monograma V)
- **10%** Cyber Orange (CTAs, números-chave, destaques únicos)

> O laranja é tempero, não prato principal. Usado demais, perde força.

### Por que essas três e não outras

- **Deep Space Blue, não preto puro**: preto é morto e absoluto. Deep Space tem um tom azulado quase imperceptível que dá vida cibernética em telas OLED/AMOLED/LCD. É a cor de um terminal premium, não de uma folha em branco invertida.
- **Cyber Orange, não vermelho/amarelo/roxo**: vermelho é alerta; amarelo é frívolo; roxo é luxo passivo. `#FF5300` está no limite vermelho-laranja — carrega a urgência do vermelho com o otimismo do laranja. É a cor de quem acelera.
- **Apenas três cores**: marcas com paletas extensas viram bibliotecas esquecíveis. Marcas com três cores viram memória visual.

### Cores funcionais (suporte)

Para feedback de UI apenas — **não** participam da identidade de marca:

| Token | HEX | Uso |
|-------|-----|-----|
| `--vs-success` | `#10B981` | Notificações de sucesso (preferir Cyber Orange quando possível) |
| `--vs-warning` | `#F59E0B` | Avisos não-críticos |
| `--vs-danger` | `#EF4444` | Alertas críticos apenas |
| `--vs-text-secondary` | `#94A3B8` | Texto secundário, labels, captions |
| `--vs-border` | `#1E293B` | Bordas sutis sobre Deep Space |
| `--vs-surface` | `#0A0F1F` | Cards e superfícies elevadas |
| `--vs-surface-2` | `#0F172A` | Superfícies duplamente elevadas (modais) |

---

## 4. TIPOGRAFIA

### A marca É a tipografia

Não há símbolo, ícone ou pictograma. O monograma VS é a marca completa. Toda a força visual nasce da escolha tipográfica e da relação cromática entre as duas letras.

### Stack tipográfico

| Família | Uso | Pesos | Observações |
|---------|-----|-------|-------------|
| **Poppins** | Display, logo, headlines | 800, 900 + Italic | Sempre **Black Italic** no monograma. Geométrica, robusta. Itálico transmite velocidade e dinamismo. |
| **Montserrat** | Corpo, taglines, UI | 400, 500, 600, 700 | Sans-serif limpa, alta legibilidade digital. Taglines em CAIXA ALTA com tracking 0.25–0.30em. |
| **JetBrains Mono** | Código, números técnicos, metadados | 400, 500 | Para badges de versão, IDs, headers de seção tipo "— 03 / PALETA". |

### Escala tipográfica (Major Third — 1.250)

| Token | Tamanho | Line-height | Uso |
|-------|---------|-------------|-----|
| `--vs-text-xs` | 12px (0.75rem) | 1.4 | Captions, metadados |
| `--vs-text-sm` | 14px (0.875rem) | 1.5 | Texto auxiliar, labels |
| `--vs-text-base` | 16px (1rem) | 1.6 | Corpo padrão |
| `--vs-text-lg` | 18px (1.125rem) | 1.5 | Parágrafos de destaque |
| `--vs-text-xl` | 22px (1.375rem) | 1.4 | Subheaders |
| `--vs-text-2xl` | 28px (1.75rem) | 1.3 | H3 |
| `--vs-text-3xl` | 36px (2.25rem) | 1.2 | H2 |
| `--vs-text-4xl` | 48px (3rem) | 1.1 | H1 |
| `--vs-text-5xl` | 64px (4rem) | 1.05 | Display secundário |
| `--vs-text-6xl` | 96px (6rem) | 1.0 | Display hero |

### Regras tipográficas

- **Headlines**: Poppins Black Italic 900, tracking `-0.025em` (-2.5%), line-height 1.0–1.1.
- **Taglines em caixa alta**: Montserrat 500/600, tracking `0.25em` a `0.30em`.
- **Corpo**: Montserrat 400, line-height 1.5–1.6, max-width 65ch para leitura confortável.
- **Headers de seção** (estilo "— 03 / PALETA"): JetBrains Mono ou Montserrat 500, caixa alta, tracking amplo, com em-dash inicial.
- **Nunca** serifadas. **Nunca** manuscritas.

---

## 5. SEMIÓTICA — O QUE V E S SIGNIFICAM

O monograma VS não é arbitrário. As duas letras carregam papéis semânticos opostos e complementares.

### V — A Fundação
- **Cor**: Branco (em fundo escuro) ou Preto (em fundo claro). Cor neutra, ancorada.
- **Significado**: Vendas · Visão · Estrutura.
- **Papel narrativo**: a base sólida, a transparência tecnológica, a engenharia que sustenta a operação. **O "V" é o que não pode falhar.**

### S — A Solução
- **Cor**: Cyber Orange `#FF5300`. Cor que brilha e age.
- **Significado**: Soluções · Garra · Diferencial.
- **Papel narrativo**: o diferencial humano, a paixão da equipe, o resultado entregue. **O "S" é o que faz o cliente lembrar.**

### A conexão
O itálico cria continuidade visual; a proximidade entre V e S simboliza que **vendas e tecnologia não são duas coisas — são a mesma coisa**.

> "V sustenta. S resolve. Juntas, são uma operação."

---

## 6. PRINCÍPIOS DE DESIGN

### 6.1 Flat design moderno
Sem 3D, sem texturas, sem gradientes coloridos. Tipografia robusta carrega a marca.

### 6.2 Alto contraste sempre
Texto branco sobre Deep Space, ou preto sobre Cyber Orange. Razão de contraste mínima 7:1 (WCAG AAA quando possível).

### 6.3 Espaçamento generoso
Densidade baixa. UI apertada quebra o princípio. Componentes respiram.

### 6.4 Geometria limpa
Cantos: `border-radius` 4px–16px. Nada arredondado em excesso (sem pílulas, exceto badges).

### 6.5 Hierarquia brutal
Um único CTA primário por viewport. Múltiplos botões laranja diluem a hierarquia.

### 6.6 Restrição como força
Em caso de dúvida: **remover, não adicionar**. Se um elemento não tem função, ele é cortado.

---

## 7. DO'S & DON'TS (consolidado)

### ✅ FAÇA

- Use Deep Space Blue como background dominante
- Reserve Cyber Orange para CTAs e destaques únicos
- Aplique Poppins Black Italic no monograma VS
- Mantenha tracking amplo em taglines em caixa alta
- Escreva copy direta, em frases curtas e orientadas a resultado
- Faça o "V" branco/preto e o "S" laranja na assinatura padrão
- Trabalhe em flat design moderno — alto contraste, geometria limpa
- Use números reais e métricas concretas em comunicação
- Respeite a proporção 70/20/10 (escuro/branco/laranja)

### ❌ NÃO FAÇA

- Adicionar efeitos 3D, sombras dramáticas ou texturas no logo
- Usar gradientes coloridos no fundo principal
- Quebrar o monograma em ícone, símbolo ou pictograma separado
- Incluir cores além das três oficiais em peças de marca
- Escrever copy genérica de marketing ("transformação digital", "soluções inovadoras")
- Aplicar Cyber Orange em mais de uma ação primária por tela
- Usar fontes serifadas ou manuscritas em qualquer peça VS
- Reduzir o monograma abaixo de 8mm impresso ou 24px digital
- Voltar para a paleta azul neon sob qualquer pretexto

---

## 8. CHECKLIST DE VALIDAÇÃO

Antes de publicar qualquer peça em nome da VS, valide:

- [ ] Background em Deep Space Blue (`#050814`)?
- [ ] Cyber Orange aparece exclusivamente em CTAs/destaques únicos?
- [ ] Há apenas UM CTA primário por viewport?
- [ ] Tipografia respeita Poppins (display) + Montserrat (corpo)?
- [ ] Copy é direta, curta, com números reais?
- [ ] Nenhum elemento decorativo sem função?
- [ ] Nenhum gradiente, 3D, textura ou sombra dramática?
- [ ] Proporção 70/20/10 está visível na peça?
- [ ] O monograma VS, se presente, tem mínimo 24px digital / 8mm impresso?
- [ ] Não há nenhuma palavra proibida (ver `brand/BRAND_VOICE.md`)?

Se alguma resposta for "não", a peça não está pronta.

---

**Esta é a fonte da verdade. Toda decisão futura deve ser checada contra este documento.**
