# VS DESIGN SYSTEM v2026.1

**Fonte da verdade visual, tipográfica, semântica e de comunicação da VS Soluções.**

Este pacote é a tradução executável do `VS Brand Bible 2026`. Qualquer interface, deck, landing page, dashboard, e-mail, prompt de IA, copy ou componente gerado em nome da VS deve passar por este documento antes de ser produzido.

---

## COMO USAR ESTE PACOTE (instrução pro Claude Code)

> **Antes de gerar qualquer código, copy ou peça visual em nome da VS Soluções, leia os arquivos nesta ordem:**
>
> 1. `DESIGN_SYSTEM.md` — visão estratégica e princípios não-negociáveis
> 2. `tokens/tokens.css` + `tokens/tokens.ts` — variáveis técnicas (cores, fontes, espaçamento)
> 3. `brand/BRAND_VOICE.md` — tom de voz, copy, palavras proibidas
> 4. `brand/LOGO_USAGE.md` — regras do monograma VS
> 5. `ui/COMPONENTS.md` — specs industriais de cada componente
> 6. `ui/LAYOUT_RULES.md` — grid, espaçamento, hierarquia
> 7. `ai/AI_DIRECTIVES.md` — regras obrigatórias quando uma LLM gerar conteúdo VS
>
> Ao finalizar, valide contra `assets/reference.html` — se o output não se parece com a referência, está errado.

---

## ESTRUTURA

```
vs-design-system/
├── README.md                  ← Você está aqui
├── DESIGN_SYSTEM.md           ← Documento mestre estratégico
│
├── tokens/
│   ├── tokens.css             ← CSS Variables (importar globalmente)
│   ├── tokens.ts              ← Mesmo conteúdo em TypeScript
│   └── reset.css              ← Reset CSS opinativo da VS
│
├── brand/
│   ├── BRAND_VOICE.md         ← Tom de voz, copy, palavras proibidas
│   ├── SEMIOTICS.md           ← Semiótica V/S, narrativa
│   └── LOGO_USAGE.md          ← Regras do monograma e variações
│
├── ui/
│   ├── COMPONENTS.md          ← Specs de TODOS os componentes
│   ├── LAYOUT_RULES.md        ← Grid, espaçamento, breakpoints
│   ├── MOTION.md              ← Animações, transições, easing
│   └── components-react/      ← Componentes React + CSS puro de referência
│
├── ai/
│   └── AI_DIRECTIVES.md       ← Regras obrigatórias para LLMs
│
└── assets/
    ├── logo-vs-dark.svg       ← Monograma fundo escuro (V branco + S laranja)
    ├── logo-vs-light.svg      ← Monograma fundo claro (V preto + S laranja)
    ├── logo-vs-cyber.svg      ← Monograma fundo Cyber Orange
    ├── logo-vs-tagline.svg    ← Monograma + tagline "VENDAS DE SOLUÇÕES"
    └── reference.html         ← HTML standalone com todos componentes
```

---

## REGRAS NÃO-NEGOCIÁVEIS

1. **Background**: sempre `#050814` (Deep Space Blue). Modo claro só em e-mails transacionais.
2. **CTA**: sempre `#FF5300` (Cyber Orange). Um único CTA primário por viewport.
3. **Tipografia**: `Poppins Black Italic` (display/logo) + `Montserrat` (corpo/UI).
4. **Proporção cromática**: 70% Deep Space · 20% Branco · 10% Cyber Orange.
5. **Sem 3D, sem gradientes coloridos, sem texturas, sem ícones decorativos.**
6. **Copy**: direta, em frases curtas, orientada a resultado, com números reais.
7. **Em caso de dúvida: remover, não adicionar.**

---

## VERSIONAMENTO

- **v2026.1** — Versão atual. Cyber Orange + Deep Space Blue. Substitui W1 e W4.
- Mudanças requerem nova versão oficial e atualização deste pacote.

---

**VS Soluções © 2026** · Vale do Paraíba · Brasil
