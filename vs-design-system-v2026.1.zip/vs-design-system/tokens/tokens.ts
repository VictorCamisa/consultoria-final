/**
 * VS DESIGN SYSTEM — TOKENS (TypeScript)
 * Versão: 2026.1 · Era Cyber Orange
 *
 * Espelha 1:1 o conteúdo de tokens.css. Use este módulo quando precisar
 * acessar tokens em JavaScript/TypeScript (cálculos dinâmicos, charts,
 * estilos inline, theming programático).
 *
 * Regra: NUNCA defina valores de marca fora deste arquivo. Se precisar
 * de uma exceção, adicione um token novo aqui e documente o uso.
 */

export const vsColors = {
  // Cores de marca (não-negociáveis)
  deepSpace:      '#050814',
  cyberOrange:    '#FF5300',
  pureWhite:      '#FFFFFF',
  pureBlack:      '#000000',

  // Variações funcionais sobre Deep Space
  surface:        '#0A0F1F',
  surface2:       '#0F172A',
  surface3:       '#1A2236',
  border:         '#1E293B',
  borderStrong:   '#334155',
  borderCyber:    'rgba(255, 83, 0, 0.4)',

  // Cyber Orange variações
  cyberHover:     '#E64A00',
  cyberActive:    '#CC4200',
  cyberSoft:      'rgba(255, 83, 0, 0.12)',
  cyberSoft2:     'rgba(255, 83, 0, 0.20)',
  cyberGlow:      'rgba(255, 83, 0, 0.35)',

  // Texto
  textPrimary:    '#FFFFFF',
  textSecondary:  '#94A3B8',
  textTertiary:   '#64748B',
  textOnCyber:    '#050814',
  textOnLight:    '#050814',

  // Funcionais (apenas feedback de UI, NUNCA identidade)
  success:        '#10B981',
  successSoft:    'rgba(16, 185, 129, 0.12)',
  warning:        '#F59E0B',
  warningSoft:    'rgba(245, 158, 11, 0.12)',
  danger:         '#EF4444',
  dangerSoft:     'rgba(239, 68, 68, 0.12)',
  info:           '#3B82F6',
  infoSoft:       'rgba(59, 130, 246, 0.12)',
} as const;

export const vsTypography = {
  fontDisplay:    "'Poppins', system-ui, -apple-system, sans-serif",
  fontBody:       "'Montserrat', system-ui, -apple-system, sans-serif",
  fontMono:       "'JetBrains Mono', 'Fira Code', Consolas, monospace",

  weight: {
    regular:    400,
    medium:     500,
    semibold:   600,
    bold:       700,
    extrabold:  800,
    black:      900,
  },

  size: {
    xs:    '0.75rem',     // 12px
    sm:    '0.875rem',    // 14px
    base:  '1rem',        // 16px
    lg:    '1.125rem',    // 18px
    xl:    '1.375rem',    // 22px
    '2xl': '1.75rem',     // 28px
    '3xl': '2.25rem',     // 36px
    '4xl': '3rem',        // 48px
    '5xl': '4rem',        // 64px
    '6xl': '6rem',        // 96px
  },

  leading: {
    none:     1,
    tight:    1.1,
    snug:     1.25,
    normal:   1.5,
    relaxed:  1.6,
    loose:    1.75,
  },

  tracking: {
    tighter:  '-0.025em',
    tight:    '-0.015em',
    normal:   '0',
    wide:     '0.025em',
    wider:    '0.1em',
    widest:   '0.25em',
    extreme:  '0.30em',
  },
} as const;

export const vsSpacing = {
  0:  '0',
  1:  '0.25rem',
  2:  '0.5rem',
  3:  '0.75rem',
  4:  '1rem',
  5:  '1.25rem',
  6:  '1.5rem',
  8:  '2rem',
  10: '2.5rem',
  12: '3rem',
  16: '4rem',
  20: '5rem',
  24: '6rem',
  32: '8rem',
} as const;

export const vsRadius = {
  none:  '0',
  sm:    '4px',
  md:    '8px',
  lg:    '12px',
  xl:    '16px',
  '2xl': '24px',
  full:  '9999px',
} as const;

export const vsShadows = {
  none:     'none',
  sm:       '0 1px 2px rgba(0, 0, 0, 0.4)',
  md:       '0 4px 12px rgba(0, 0, 0, 0.4)',
  lg:       '0 12px 32px rgba(0, 0, 0, 0.5)',
  xl:       '0 24px 48px rgba(0, 0, 0, 0.6)',
  cyber:    '0 0 0 3px rgba(255, 83, 0, 0.35)',
  cyberLg:  '0 0 24px rgba(255, 83, 0, 0.45)',
  inset:    'inset 0 1px 2px rgba(0, 0, 0, 0.5)',
} as const;

export const vsBreakpoints = {
  sm:    '640px',
  md:    '768px',
  lg:    '1024px',
  xl:    '1280px',
  '2xl': '1536px',
} as const;

export const vsMotion = {
  duration: {
    instant: '100ms',
    fast:    '180ms',
    base:    '240ms',
    slow:    '360ms',
    slower:  '500ms',
  },
  ease: {
    linear:  'linear',
    out:     'cubic-bezier(0.16, 1, 0.3, 1)',
    in:      'cubic-bezier(0.7, 0, 0.84, 0)',
    inOut:   'cubic-bezier(0.85, 0, 0.15, 1)',
    spring:  'cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
} as const;

export const vsZIndex = {
  base:           0,
  dropdown:       100,
  sticky:         200,
  fixed:          300,
  modalBackdrop:  400,
  modal:          500,
  popover:        600,
  tooltip:        700,
  toast:          800,
} as const;

export const vsLayout = {
  container: {
    sm:    '640px',
    md:    '768px',
    lg:    '1024px',
    xl:    '1280px',
    '2xl': '1440px',
  },
  content: {
    narrow: '65ch',
    medium: '80ch',
    wide:   '100%',
  },
  logo: {
    minDigital: '24px',
    minPrint:   '8mm',
    clearSpace: 0.5,
  },
} as const;

/**
 * Token agregado — útil para passar como prop de tema.
 */
export const vsTokens = {
  colors:      vsColors,
  typography:  vsTypography,
  spacing:     vsSpacing,
  radius:      vsRadius,
  shadows:     vsShadows,
  breakpoints: vsBreakpoints,
  motion:      vsMotion,
  zIndex:      vsZIndex,
  layout:      vsLayout,
} as const;

export type VSTokens = typeof vsTokens;
export default vsTokens;
